package kr.samcheonpo.dolmen;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
