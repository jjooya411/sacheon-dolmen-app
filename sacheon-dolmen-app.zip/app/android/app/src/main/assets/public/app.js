/* 휴대폰 앱에서만 필요한 동작 (웹 브라우저에서는 아무 일도 하지 않음) */
(function () {
  var Cap = window.Capacitor;
  if (!Cap || !Cap.isNativePlatform || !Cap.isNativePlatform()) return;

  // 앱 느낌: 길게 눌렀을 때 파란 터치 하이라이트·텍스트 선택 줄이기 (입력칸은 그대로)
  var st = document.createElement("style");
  st.textContent =
    "*{-webkit-tap-highlight-color:transparent}" +
    "body{-webkit-user-select:none;user-select:none;overscroll-behavior:none}" +
    "input,textarea,[contenteditable]{-webkit-user-select:text;user-select:text}";
  document.head.appendChild(st);

  // 카카오맵·네이버지도 같은 바깥 링크는 앱 안이 아니라 지도 앱/브라우저로 열기
  document.addEventListener(
    "click",
    function (e) {
      var a = e.target.closest && e.target.closest("a[href]");
      if (!a) return;
      var href = a.getAttribute("href") || "";
      if (!/^(https?:|tel:|mailto:|geo:|intent:)/i.test(href)) return;
      if (href.indexOf(location.origin) === 0) return;
      e.preventDefault();
      // Capacitor는 앱 바깥 주소로 이동하려 하면 휴대폰의 기본 앱(지도 앱·브라우저)으로 넘겨 줍니다.
      location.href = href;
    },
    true
  );

  // 안드로이드 뒤로 가기 버튼: 열린 창부터 닫고, 아무것도 없으면 앱 종료
  var App = Cap.Plugins && Cap.Plugins.App;
  if (App && App.addListener) {
    App.addListener("backButton", function () {
      var dim = document.getElementById("dim");
      var lb = document.getElementById("lb") || document.querySelector(".lb.on, .lightbox.on");
      var picking = false;
      try { picking = typeof pickMode !== "undefined" && !!pickMode; } catch (err) {}
      var open =
        (dim && dim.classList.contains("on")) ||
        (lb && lb.classList.contains("on")) ||
        picking;
      if (open) {
        document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true }));
      } else {
        App.exitApp();
      }
    });
  }
})();
