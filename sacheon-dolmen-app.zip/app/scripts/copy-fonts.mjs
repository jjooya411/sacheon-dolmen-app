// Google Fonts 대신 앱 안에 글꼴을 넣어 인터넷 없이도 같은 모양으로 보이게 합니다.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync, existsSync } from "node:fs";
import { join } from "node:path";

const out = "www/fonts";
mkdirSync(join(out, "files"), { recursive: true });
const sets = [
  ["@fontsource/jua", ["400"]],
  ["@fontsource/noto-sans-kr", ["400", "500", "700", "900"]],
];
let css = "";
for (const [pkg, weights] of sets) {
  const base = join("node_modules", pkg);
  for (const w of weights) {
    const src = readFileSync(join(base, `${w}.css`), "utf8");
    // woff 대체 경로는 쓰지 않으므로 제거 (Android WebView는 woff2 지원)
    const clean = src.replace(/,\s*url\(\.\/files\/[^)]+\.woff\) format\('woff'\)/g, "");
    css += clean.replace(/url\(\.\/files\/([^)]+\.woff2)\)/g, (m, f) => {
      const from = join(base, "files", f);
      if (existsSync(from)) copyFileSync(from, join(out, "files", f));
      return `url(./files/${f})`;
    }) + "\n";
  }
}
writeFileSync(join(out, "fonts.css"), css);
console.log("fonts copied →", out);
