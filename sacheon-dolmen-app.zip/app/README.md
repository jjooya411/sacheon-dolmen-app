# 사천 고인돌 탐험 지도 – 안드로이드 앱

웹 버전(v1.7)을 Capacitor로 감싼 안드로이드 앱 프로젝트입니다.
글꼴까지 앱 안에 들어 있어 **인터넷이 없어도** 지도·퀴즈·기록이 모두 동작합니다.
(네이버/카카오 지도 버튼만 인터넷이 필요하며, 휴대폰의 지도 앱이나 브라우저로 열립니다.)

## 1. APK 받는 가장 쉬운 방법 (GitHub, 설치 프로그램 불필요)
1. GitHub에 새 저장소를 만들고 이 폴더 전체를 올립니다(main 브랜치).
2. 저장소의 **Actions** 탭 → "Android APK 만들기"가 자동 실행됩니다(약 5~8분).
3. 완료된 실행을 열고 맨 아래 **Artifacts → sacheon-dolmen-android**를 내려받습니다.
4. 압축을 풀면 `app-debug.apk`가 있습니다. 휴대폰으로 옮겨 설치합니다.
   (처음 설치 시 "출처를 알 수 없는 앱 설치 허용"을 켜야 합니다.)

## 2. 컴퓨터에서 직접 빌드 (Android Studio)
```
npm install
npm run sync      # 웹 파일·글꼴을 android 폴더로 복사
npm run open      # Android Studio로 열기 → ▶ 실행 또는 Build > Build APK
```
필요: Node.js 22, Android Studio(최신), JDK 21

## 3. 내용 고치기
- 화면·내용은 `www/index.html` 하나만 고치면 됩니다. 고친 뒤 `npm run sync`.
- 앱 전용 동작(뒤로 가기 버튼, 바깥 링크 열기)은 `www/app.js`.
- 아이콘·시작 화면 원본은 `assets/` 폴더 → `npx @capacitor/assets generate --android`.
- 새 버전을 낼 때는 `android/app/build.gradle`의 `versionCode`(숫자 올리기)와 `versionName`을 바꿉니다.

## 4. Play 스토어에 올리려면 (선택)
서명 키를 만들고 GitHub 저장소 Settings → Secrets에 아래 4개를 넣으면
Actions가 서명된 `app-release.aab`(스토어 제출용)도 함께 만듭니다.
```
keytool -genkey -v -keystore release.keystore -alias dolmen -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.keystore   # 이 출력값을 ANDROID_KEYSTORE_BASE64 에 넣기
```
- `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`(예: dolmen), `ANDROID_KEY_PASSWORD`
- 키 파일과 비밀번호는 잃어버리면 같은 앱을 업데이트할 수 없으니 따로 안전하게 보관하세요.

## 참고
- 발견 기록과 사진은 휴대폰의 앱 안에만 저장됩니다. 앱을 지우면 함께 지워집니다.
- 웹 버전과 앱 버전의 기록은 서로 공유되지 않습니다.
- 아이폰 앱은 Mac과 Apple 개발자 계정(연 99달러)이 있어야 만들 수 있습니다.
  필요하면 `npm i @capacitor/ios && npx cap add ios` 후 Xcode로 빌드합니다.
